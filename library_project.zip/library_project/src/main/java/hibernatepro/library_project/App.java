package hibernatepro.library_project;

import java.util.Scanner;

import hibernatepro.library_project.service.Authsystemservice;
import hibernatepro.library_project.service.Bookservice;
import hibernatepro.library_project.service.Categoryservice;
import hibernatepro.library_project.service.Librarianservice;
import hibernatepro.library_project.service.MemberReportservice;
import hibernatepro.library_project.service.Membersservice;

public class App {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome to the Library Management System");

        while (true) {
            System.out.println("\n1) Librarian Login");
            System.out.println("2) Member Login");
            System.out.println("3) Exit");
            System.out.print("Choose your option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    librarianLogin();
                    break;
                case 2:
                    memberLogin();
                    break;
                case 3:
                    System.out.println("Exiting the system. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void librarianLogin() {
        System.out.print("\nEnter Librarian id: ");
        String email = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        // Simulated authentication (replace with Hibernate query)
        if (email.equals("01") && password.equals("password")) {
            System.out.println("Login successful!");
            librarianOperations();
        } else {
            System.out.println("Invalid credentials!");
        }
    }

    private static void librarianOperations() {
        while (true) {
            System.out.println("\nLibrarian Operations:");
            System.out.println("1) Add a Member");
            System.out.println("2) Add a Book");
            System.out.println("3) View all Members");
            System.out.println("4) Generate Member Reports");
            System.out.println("5) Update Book");
            System.out.println("6) Delete Book");
            System.out.println("7) Exit");
            System.out.print("Choose your option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addMember();
                    break;
                case 2:
                    addBook();
                    break;
                case 3:
                    viewAllMembers();
                    break;
                case 4:
                    generateMemberReports();
                    break;
                case 5:
                    updateBook();
                    break;
                case 6:
                    deleteBook();
                    break;
                case 7:
                    return; // Exit to the main menu
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void memberLogin() {
        System.out.print("\nEnter Member ID: ");
        String memberId = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        // Simulated authentication (replace with Hibernate query)
        if (memberId.equals("member123") && password.equals("password")) {
            System.out.println("Login successful!");
            memberOperations();
        } else {
            System.out.println("Invalid credentials!");
        }
    }

    private static void memberOperations() {
        while (true) {
            System.out.println("\nMember Operations:");
            System.out.println("1) View all Books");
            System.out.println("2) Borrow a Book");
            System.out.println("3) Search for a Book");
            System.out.println("4) Exit");
            System.out.print("Choose your option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    viewAllBooks();
                    break;
                case 2:
                    borrowBook();
                    break;
                case 3:
                    searchBook();
                    break;
                case 4:
                    return; // Exit to the main menu
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    // Librarian methods
    private static void addMember() {
        System.out.println("\nAdding a new member...");
        System.out.print("Enter Member ID: ");
        int MemberId = scanner.nextInt();
        System.out.print("Enter Member Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Phone: ");
        String phone = scanner.nextLine();
        System.out.print("Enter Membership Date: ");
        String date = scanner.nextLine();

        System.out.println("Member added successfully: " + name);
    }

    private static void addBook() {
        System.out.println("\nAdding a new book...");
        System.out.print("Enter Book ID: ");
        int id = scanner.nextInt();
        System.out.print("Enter Book Title: ");
        String title = scanner.nextLine();
        System.out.print("Enter Author: ");
        String author = scanner.nextLine();
        System.out.print("Enter Year of Publication: ");
        int year = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Book added successfully: " + title);
    }

    private static void viewAllMembers() {
        System.out.println("\nFetching all members...");
        System.out.println("Member:01, Priya Joshi, Phone: 7977328834");
        System.out.println("Member:02, Arjun Gupta, Phone: 9876543210");
        System.out.println("Member:03, Sachin Yadav, Phone: 8765467890");
        System.out.println("Member:04, Sapna Joshi, Phone: 7234567890");
        System.out.println("Member:05, Bhawna Bora, Phone: 9987003992"
        		+ "");
    }

    private static void generateMemberReports() {
        System.out.println("\nGenerating reports by memberID...");
        System.out.print("Enter Member ID: ");
        int MemberId = scanner.nextInt();
        
        System.out.println("Here is the generated Report..");
        System.out.println("Member:01, Priya Joshi");
        System.out.println("IssueDate: 2024-15-01");
        System.out.println("DueDate: 2024-20-01");
    }

    private static void updateBook() {
        System.out.println("\nUpdating a book...");
        System.out.print("Enter Book ID: ");
        int bookId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter New Title: ");
        String newTitle = scanner.nextLine();

        System.out.println("Book updated successfully: " + newTitle);
    }

    private static void deleteBook() {
        System.out.println("\nDeleting a book...");
        System.out.print("Enter Book ID: ");
        int bookId = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Book deleted successfully.");
    }

    // Member methods
    private static void viewAllBooks() {
        System.out.println("\nFetching all books...");
        System.out.println("Book:01, 'Mathematics', Author: Ramanujan, Year: 1994");
        System.out.println("Book:02, 'Java Programming', Author: John Doe, Year: 1996");
        System.out.println("Book:03, 'Physics', Author: Albert Einstein , Year: 1987");
        System.out.println("Book:04, 'Biology', Author: Lamarck, Year: 1884");
    }

    private static void borrowBook() {
        System.out.println("\nBorrowing a book...");
        System.out.print("Enter Book ID: ");
        int bookId = scanner.nextInt();
        scanner.nextLine();
        
        System.out.println("Book borrowed successfully.");
    }

    private static void searchBook() {
        System.out.println("\nSearching for a book...");
        System.out.print("Enter Book Title or Author: ");
        String query = scanner.nextLine();

        System.out.println("Book found: 'Java Programming', Author: John Doe, Year: 2020");
    }
}

