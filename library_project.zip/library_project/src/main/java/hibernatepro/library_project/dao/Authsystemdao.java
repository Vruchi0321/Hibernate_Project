package hibernatepro.library_project.dao;

import hibernatepro.library_project.entity.Authsystem;

import java.util.List;

public interface Authsystemdao {
    void saveAuthsystem(Authsystem authsystem);
    Authsystem getAuthsystemById(int logid);
    List<Authsystem> getAllAuthsystems();
    void updateAuthsystem(Authsystem authsystem);
    void deleteAuthsystemById(int logid);
    Authsystem findByUsername(String username); // Optional for unique username queries
}