package hibernatepro.library_project.dao;

import hibernatepro.library_project.entity.Category;
import java.util.List;

public interface Categorydao {
    void saveCategory(Category category);
    Category getCategoryById(int id);
    List<Category> getAllCategories();
    void updateCategory(Category category);
    void deleteCategoryById(int id);
}
