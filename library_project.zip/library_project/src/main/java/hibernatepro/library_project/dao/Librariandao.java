package hibernatepro.library_project.dao;

import hibernatepro.library_project.entity.Librarian;
import java.util.List;

public interface Librariandao {
    void saveLibrarian(Librarian librarian);
    Librarian getLibrarianById(int id);
    List<Librarian> getAllLibrarians();
    void updateLibrarian(Librarian librarian);
    void deleteLibrarianById(int id);
	void addLibrarian(Librarian librarian);
}