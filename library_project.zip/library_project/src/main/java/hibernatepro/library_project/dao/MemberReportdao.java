package hibernatepro.library_project.dao;

import hibernatepro.library_project.entity.MemberReport;
import java.util.List;

public interface MemberReportdao {
    void saveMemberReport(MemberReport memberReport);
    MemberReport getMemberReportById(int id);
    List<MemberReport> getAllMemberReports();
    void updateMemberReport(MemberReport memberReport);
    void deleteMemberReportById(int id);
}
