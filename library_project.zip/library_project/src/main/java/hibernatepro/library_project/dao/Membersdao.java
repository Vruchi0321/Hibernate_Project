package hibernatepro.library_project.dao;

import hibernatepro.library_project.entity.Members;
import java.util.List;

public interface Membersdao {
    void saveMember(Members member);
    Members getMemberById(int id);
    List<Members> getAllMembers();
    void updateMember(Members member);
    void deleteMemberById(int id);
}
