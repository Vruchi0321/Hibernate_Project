package hibernatepro.library_project.daoimpl;

import hibernatepro.library_project.dao.Librariandao;
import hibernatepro.library_project.entity.Librarian;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Librariandaoimpl implements Librariandao {

    private SessionFactory sessionFactory;

    // Constructor to initialize SessionFactory
    public Librariandaoimpl() {
        sessionFactory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Librarian.class).buildSessionFactory();
    }

    @Override
    public void saveLibrarian(Librarian librarian) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.save(librarian);
            transaction.commit();
            System.out.println("Librarian saved successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Librarian getLibrarianById(int id) {
        Librarian librarian = null;
        try (Session session = sessionFactory.openSession()) {
            librarian = session.get(Librarian.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return librarian;
    }

    @Override
    public List<Librarian> getAllLibrarians() {
        List<Librarian> librarians = null;
        try (Session session = sessionFactory.openSession()) {
            librarians = session.createQuery("from Librarian", Librarian.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return librarians;
    }

    @Override
    public void updateLibrarian(Librarian librarian) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.update(librarian);
            transaction.commit();
            System.out.println("Librarian updated successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteLibrarianById(int id) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            Librarian librarian = session.get(Librarian.class, id);
            if (librarian != null) {
                session.delete(librarian);
                System.out.println("Librarian deleted successfully!");
            } else {
                System.out.println("Librarian not found with id: " + id);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // Close the SessionFactory
    public void closeSessionFactory() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }

	@Override
	public void addLibrarian(Librarian librarian) {
		// TODO Auto-generated method stub
		
	}
}
