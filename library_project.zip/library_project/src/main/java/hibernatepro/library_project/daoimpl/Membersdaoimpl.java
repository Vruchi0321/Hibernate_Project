package hibernatepro.library_project.daoimpl;

import hibernatepro.library_project.dao.Membersdao;
import hibernatepro.library_project.entity.Members;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import java.util.List;

public class Membersdaoimpl implements Membersdao {

    private SessionFactory sessionFactory;

    // Constructor to initialize SessionFactory
    public Membersdaoimpl() {
        sessionFactory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Members.class).buildSessionFactory();
    }

    @Override
    public void saveMember(Members member) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.save(member);
            transaction.commit();
            System.out.println("Member saved successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public Members getMemberById(int id) {
        Members member = null;
        try (Session session = sessionFactory.openSession()) {
            member = session.get(Members.class, id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return member;
    }

    @Override
    public List<Members> getAllMembers() {
        List<Members> members = null;
        try (Session session = sessionFactory.openSession()) {
            members = session.createQuery("from Members", Members.class).list();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return members;
    }

    @Override
    public void updateMember(Members member) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            session.update(member);
            transaction.commit();
            System.out.println("Member updated successfully!");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteMemberById(int id) {
        Transaction transaction = null;
        try (Session session = sessionFactory.openSession()) {
            transaction = session.beginTransaction();
            Members member = session.get(Members.class, id);
            if (member != null) {
                session.delete(member);
                System.out.println("Member deleted successfully!");
            } else {
                System.out.println("Member not found with id: " + id);
            }
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            e.printStackTrace();
        }
    }

    // Close the SessionFactory
    public void closeSessionFactory() {
        if (sessionFactory != null) {
            sessionFactory.close();
        }
    }
}
