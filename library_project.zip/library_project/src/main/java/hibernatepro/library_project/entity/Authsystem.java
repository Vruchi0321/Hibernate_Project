package hibernatepro.library_project.entity;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import jakarta.persistence.*;

@Entity
@Table(name = "Authentication_system")
public class Authsystem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @NotNull(message = "Password cannot be null")
    @Size(min = 8, message = "Password must be at least 8 characters long")
    @Pattern(regexp = ".*[A-Z].*", message = "Password must contain at least one uppercase letter")
    @Pattern(regexp = ".*[a-z].*", message = "Password must contain at least one lowercase letter")
    @Pattern(regexp = ".*[0-9].*", message = "Password must contain at least one digit")
    private String password;

    @OneToOne(mappedBy = "authentication")
    private Members member;

    @OneToOne(mappedBy = "authentication")
    private Librarian librarian;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Members getMember() {
		return member;
	}

	public void setMember(Members member) {
		this.member = member;
	}

	public Librarian getLibrarian() {
		return librarian;
	}

	public void setLibrarian(Librarian librarian) {
		this.librarian = librarian;
	}

	public Authsystem(Long id, String username,
			@NotNull(message = "Password cannot be null") @Size(min = 8, message = "Password must be at least 8 characters long") @Pattern(regexp = ".*[A-Z].*", message = "Password must contain at least one uppercase letter") @Pattern(regexp = ".*[a-z].*", message = "Password must contain at least one lowercase letter") @Pattern(regexp = ".*[0-9].*", message = "Password must contain at least one digit") String password,
			Members member, Librarian librarian) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.member = member;
		this.librarian = librarian;
	}

	public Authsystem() {
	}

	@Override
	public String toString() {
		return "Authsystem [id=" + id + ", username=" + username + ", password=" + password + ", member=" + member
				+ ", librarian=" + librarian + "]";
	}

    

}
