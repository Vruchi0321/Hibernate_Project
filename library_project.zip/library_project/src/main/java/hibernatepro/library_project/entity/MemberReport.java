package hibernatepro.library_project.entity;

import java.util.Date;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import jakarta.persistence.*;

@Entity
@Table(name = "Member_reports")
public class MemberReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @NotNull(message = "Issue date cannot be null")
    @PastOrPresent(message = "Issue date cannot be in the future")
    @Column(name = "issue_date")
    private Date issueDate;

    @PastOrPresent(message = "Return date cannot be in the future")
    @Column(name = "return_date")
    private Date returnDate;

    @NotNull(message = "Due date cannot be null")
    @FutureOrPresent(message = "Due date must be today or in the future")
    @Column(name = "due_date")
    private Date dueDate;

    @ManyToOne
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;

    @ManyToOne
    @JoinColumn(name = "member_id", nullable = false)
    private Members member;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(Date issueDate) {
		this.issueDate = issueDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public Members getMember() {
		return member;
	}

	public void setMember(Members member) {
		this.member = member;
	}

	public MemberReport(int id,
			@NotNull(message = "Issue date cannot be null") @PastOrPresent(message = "Issue date cannot be in the future") Date issueDate,
			@PastOrPresent(message = "Return date cannot be in the future") Date returnDate,
			@NotNull(message = "Due date cannot be null") @FutureOrPresent(message = "Due date must be today or in the future") Date dueDate,
			Book book, Members member) {
		super();
		this.id = id;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		this.dueDate = dueDate;
		this.book = book;
		this.member = member;
	}

	public MemberReport() {
	}

	@Override
	public String toString() {
		return "MemberReport [id=" + id + ", issueDate=" + issueDate + ", returnDate=" + returnDate + ", dueDate="
				+ dueDate + ", book=" + book + ", member=" + member + "]";
	}
    
    

}
