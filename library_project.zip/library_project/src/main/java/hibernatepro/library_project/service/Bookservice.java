package hibernatepro.library_project.service;

import hibernatepro.library_project.dao.Bookdao;
import hibernatepro.library_project.daoimpl.Bookdaoimpl;
import hibernatepro.library_project.entity.Book;

import java.util.List;

public class Bookservice {

    private Bookdao bookDao;

    // Constructor to initialize DAO
    public Bookservice() {
        bookDao = new Bookdaoimpl();
    }

    public void saveBook(Book book) {
        bookDao.saveBook(book);
    }

    public Book getBookById(int id) {
        return bookDao.getBookById(id);
    }

    public List<Book> getAllBooks() {
        return bookDao.getAllBooks();
    }

    public void updateBook(Book book) {
        bookDao.updateBook(book);
    }

    public void deleteBookById(int id) {
        bookDao.deleteBookById(id);
    }

    public void closeResources() {
        if (bookDao instanceof Bookdaoimpl) {
            ((Bookdaoimpl) bookDao).closeSessionFactory();
        }
    }

//Method to search books by title or author
public List<Book> searchBooks(String searchQuery) {
    return bookDao.searchBooks(searchQuery);  // Calls the DAO layer to query the database
}

public void updateBook(int bookId, String title, String author) {
	// TODO Auto-generated method stub
	
}
}