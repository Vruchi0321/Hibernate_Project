package hibernatepro.library_project.service;

import hibernatepro.library_project.dao.Membersdao;
import hibernatepro.library_project.daoimpl.Membersdaoimpl;
import hibernatepro.library_project.entity.Members;

import java.util.List;

public class Membersservice {

    private static Membersdao membersDao;

    // Constructor to initialize DAO
    public Membersservice() {
        membersDao = new Membersdaoimpl();
    }

    public void saveMember(Members member) {
        membersDao.saveMember(member);
    }

    public static Members getMemberById(int id) {
        return membersDao.getMemberById(id);
    }

    public List<Members> getAllMembers() {
        return membersDao.getAllMembers();
    }

    public void updateMember(Members member) {
        membersDao.updateMember(member);
    }

    public void deleteMemberById(int id) {
        membersDao.deleteMemberById(id);
    }

    public void closeResources() {
        if (membersDao instanceof Membersdaoimpl) {
            ((Membersdaoimpl) membersDao).closeSessionFactory();
        }
    }
}
